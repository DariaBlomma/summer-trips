<?php
echo "Here will be a table with common points";
?>
