PixelsDaily
=======================
Name:	Shiny Metal UI Kit
Type:	PSD
Author:	iRevoDesign


Notes
=======================
Something a bit more bold, bright, and crazy than our usual refined freebies, this shiny metal/chrome user interface kit contains a host of futuristic elements. Sliders, buttons, dials, and some sexy switches — it has it all.




Free Resource Licensing
=======================
All our free resources are licensed under a Creative Commons Attribution license. This license lets you distribute, remix, tweak, and build upon your work, even commercially, as long as you credit PixelsDaily for the original creation:

http://creativecommons.org/licenses/by/3.0/